// import axios from 'axios';
// axios.defaults.headers[process.env.API_KEY]
import { google } from 'googleapis'
import hubspot from '@hubspot/api-client'
const sheetId = '1lWfM4N7EXb6wyZ6IR0bsXftS_iv3fqA18Ea0dEcrHDg'
const sheets = google.sheets({
  version: 'v4',
  auth: process.env.GOOGLE_API_KEY
})
// const hubspot = require('@hubspot/api-client');
const HUBSPOT_API_KEY = 'pat-na1-6977c199-c7be-4141-a1f1-a7b1ba27090f'
const hubspotClient = new hubspot.Client({ accessToken: HUBSPOT_API_KEY })

async function listContactsFromGoogleSheets (spreadsheetId) {
  const request = {
    spreadsheetId: sheetId,
    ranges: ['customers!A2:E'],
    includeGridData: true
  }

  try {
    const response = (await sheets.spreadsheets.get(request)).data
    // const response = await sheets.spreadsheets.values.get({ spreadsheetId: sheetId, range: 'customers' })
    // console.log('RESPONSE:', response.sheets[0].data[0].rowData)
    const dataRows = (response.sheets[0].data[0].rowData).map((row) => row.values)
    console.log('DATA ROWS:', dataRows)
    const newObject = dataRows.map((dataRow) => dataRow.values)
    const formattedValues = newObject[0].map((value) => value.formattedValue)
    // const objects = newObject.forEach((object) => object.map((value) => value.formattedValue))
    // console.log('new object:', newObject)
    // console.log('formatted values:', formattedValues)
    // console.log('OBJECTS:', objects)
    const sheetValues = response.sheets[0].data[0].rowData[1].values
    // console.log('SHEET VALUES:', sheetValues)
    const formattedSheetValues = sheetValues.map((value) => value.formattedValue)
    return formattedSheetValues
  } catch (err) {
    console.error(err)
  }
}

// listContactsFromGoogleSheets()

async function postContactsFromGoogleSheets (contacts) {
  const index = contacts[2].indexOf('@')
  const emailDomain = contacts[2].slice((index + 1), contacts[2].length).split('.')[0]
  const commercialDomains = ['yahoo', 'hotmail', 'gmail', 'apple', 'outlook']
  let contactRequestBody = {}
  const isCommercial = commercialDomains.some((domain) => domain === emailDomain)
  if (isCommercial) {
    throw new Error('Email must be corporate')
  } else {
    contactRequestBody = {
      properties: {
        firstname: contacts[1],
        email: contacts[2],
        phone: contacts[3],
        company: contacts[0],
        website: contacts[4]
      }
    }
  }

  // const SimplePublicObjectInputForCreate = { contactRequestBody, associations: [{"to":{"id":"string"},"types":[{"associationCategory":"HUBSPOT_DEFINED","associationTypeId":0}]}] };
  // console.log('formatted contacts:', contactRequestBody);

  try {
    const apiResponse = await hubspotClient.crm.contacts.basicApi.create(contactRequestBody)
    console.log(JSON.stringify(apiResponse.body, null, 2))
  } catch (e) {
    e.message === 'HTTP request failed'
      ? console.error(JSON.stringify(e.response, null, 2))
      : console.error(e)
  }
  // axios.post(`https://api.hubapi.com/crm/v3/objects/contacts?hapikey=${HUBSPOT_API_KEY}`, formattedContacts);
}

// async function getContactsFromHubspot () {
//   const limit = 10
//   const after = undefined
//   const properties = undefined
//   const propertiesWithHistory = undefined
//   const associations = undefined
//   const archived = false

//   try {
//     const apiResponse = await hubspotClient.crm.contacts.basicApi.getPage(limit, after, properties, propertiesWithHistory, associations, archived)
//     const result = JSON.stringify(apiResponse.body, null, 2)
//     console.log('RESPONSE:', apiResponse.results)
//     // return apiResponse.body;
//     return apiResponse
//   } catch (e) {
//     e.message === 'HTTP request failed'
//       ? console.error(JSON.stringify(e.response, null, 2))
//       : console.error(e)
//   }
// }

// async function getContactById (id) {
//   try {
//     const apiResponse = await hubspotClient.crm.contacts.basicApi.getById(id, [
//       'website',
//       'company'
//     ])

//     console.log('result', JSON.stringify(apiResponse, null, 2))
//   } catch (e) {
//     e.message === 'HTTP request failed'
//       ? console.error(JSON.stringify(e.response, null, 2))
//       : console.error(e)
//   }
// }

async function run () {
  const contacts = await listContactsFromGoogleSheets()
  await postContactsFromGoogleSheets(contacts)
  // await getContactsFromHubspot();
  // await getContactById('101')
}

run()
